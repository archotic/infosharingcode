<?php 
	
	$conectare = mysqli_connect('localhost', 'id11208265_florin' , 'LLUUCCIIAANN' , 'id11208265_posts');