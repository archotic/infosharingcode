[
	{
		"timestamp": "2020-02-21 @ 08:08:21",
		"url": {
			"domain": "pbinfo",
			"frag": "",
			"path": "/",
			"proto": "https:",
			"tld": ".ro",
			"www": "www."
		},
		"inputs": [
			"andrei_bogdan",
			"trudalizator"
		]
	},
	{
		"timestamp": "2020-02-24 @ 08:58:53",
		"url": {
			"domain": "google",
			"frag": "",
			"path": "/",
			"proto": "https:",
			"tld": ".ro",
			"www": "www."
		},
		"inputs": [
			"pb"
		]
	},
	{
		"timestamp": "2020-02-24 @ 08:59:26",
		"url": {
			"domain": "pbinfo",
			"frag": "",
			"path": "/",
			"proto": "https:",
			"tld": ".ro",
			"www": "www."
		},
		"inputs": [
			"xcorbulx@gmail.com",
			"corbul9600"
		]
	},
	{
		"timestamp": "2020-02-24 @ 09:09:39",
		"url": {
			"domain": "pbinfo",
			"frag": "?pagina=conversatii&partener=Florin152004",
			"path": "/",
			"proto": "https:",
			"tld": ".ro",
			"www": "www."
		},
		"inputs": [
			"aici dami"
		]
	},
	{
		"timestamp": "2020-02-24 @ 10:28:34",
		"url": {
			"domain": "google",
			"frag": "",
			"path": "/",
			"proto": "https:",
			"tld": ".ro",
			"www": "www."
		},
		"inputs": [
			"holyland"
		]
	},
	{
		"timestamp": "2020-02-24 @ 10:34:12",
		"url": {
			"domain": "google",
			"frag": "?q=holyland&source=lnms&tbm=isch&sa=X&ved=2ahUKEwjrm43h4-nnAhVUTBUIHc1nABoQ_AUoAXoECBUQAw&biw=2133&bih=1087",
			"path": "/search",
			"proto": "https:",
			"tld": ".ro",
			"www": "www."
		},
		"inputs": [
			"tr",
			"holyland"
		]
	},
	{
		"timestamp": "2020-02-24 @ 10:34:28",
		"url": {
			"domain": "google",
			"frag": "?q=translate&source=lmns&bih=1087&biw=2133&hl=en&ved=2ahUKEwjOmN_p4-nnAhVINFAKHRrICacQ_AUoAHoECAEQAA",
			"path": "/search",
			"proto": "https:",
			"tld": ".ro",
			"www": "www."
		},
		"inputs": [
			"land\nholyland"
		]
	},
	{
		"timestamp": "2020-02-24 @ 10:47:03",
		"url": {
			"domain": "pbinfo",
			"frag": "",
			"path": "/probleme/159/inseraredupa",
			"proto": "https:",
			"tld": ".ro",
			"www": "www."
		},
		"inputs": [
			"x",
			"x",
			"p"
		]
	},
	{
		"timestamp": "2020-02-25 @ 08:41:12",
		"url": {
			"domain": "pbinfo",
			"frag": "",
			"path": "/",
			"proto": "https:",
			"tld": ".ro",
			"www": "www."
		},
		"inputs": [
			"stefanmalasinca@gmail.com",
			"wsxqazokmS1"
		]
	},
	{
		"timestamp": "2020-02-25 @ 08:42:25",
		"url": {
			"domain": "pbinfo",
			"frag": "",
			"path": "/probleme/237/sume",
			"proto": "https:",
			"tld": ".ro",
			"www": "www."
		},
		"inputs": [
			"",
			""
		]
	},
	{
		"timestamp": "2020-02-25 @ 09:06:45",
		"url": {
			"domain": "pbinfo",
			"frag": "",
			"path": "/probleme/238/zone",
			"proto": "https:",
			"tld": ".ro",
			"www": "www."
		},
		"inputs": [
			" {\n        int aux=v[i];\n        v[i]=v[n*3];\n        v[n*3]=aux;\n        ok=1;\n    }",
			" {\n        int aux=v[i];\n        v[i]=v[n*3];\n        v[n*3]=aux;\n        ok=1;\n    }",
			"#include <fstream>\nusing namespace std;\nint main()\n{\n    ifstream fin(\"zone.in\");\n    ofstream fout(\"zone.out\");\n    int n,v[301],ok=0;\n    fin>>n;\n    for(int i=1;i<=n*3;i++)\n        fin>>v[i];\n    for(int i=1;i<=n*3&&ok==0;i++)\n        if(v[i]%2==0)\n    {\n        int aux=v[i];\n        v[i]=v[n*3];\n        v[n*3]=aux;\n        ok=1;\n    }\n    for(int i=1;i<=n*3;i++)\n        fout<<v[i]<<\" \";\n    fin.close();\n    fout.close();\n}\n"
		]
	},
	{
		"timestamp": "2020-02-25 @ 12:07:50",
		"url": {
			"domain": "pbinfo",
			"frag": "?&id_sursa=21269009#a_editor",
			"path": "/probleme/98/maxim4/",
			"proto": "https:",
			"tld": ".ro",
			"www": "www."
		},
		"inputs": [
			"maxim",
			"0"
		]
	}
]