#include<iostream>
using namespace std;

int s(int n)
{
    if(n)
    {
        if(n % 2 == 0)
            return n % 10 + 1 + s(n / 10) * 10;
        return n % 10 - 1 + s(n / 10) * 10;
    }
    return 0;
}
int main()
{
    int n;
    cin >> n;
    cout << s(n);
}
