#include <iostream>
#include <cstring>
#include<fstream>
using namespace std;

int main()
{
    ifstream fin("sortcuv.in");
    ofstream fout("sortcuv.out");
    char z[21],lista[251][21];
    int c=0;
    while(fin>>z)
    {
        c++;
        strcpy(lista[c],z);
    }
    for(int i=1;i<=c;i++)
        for(int j=i+1;j<=c;j++)
            if(strcmp(lista[i],lista[j])>0)
                swap(lista[i],lista[j]);
    for(int i=1;i<=c;i++)
    {
        fout<<lista[i]<<'\n';
    }
    return 0;
}
