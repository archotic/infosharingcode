#include <bits/stdc++.h>
using namespace std;
struct data
{
    int a, l, z;
};
int data_cmp(data x, data y)
{
    if(x.a < y.a)
        return -1;
    if(x.a > y.a)
        return 1;
    if(x.l < y.l)
        return -1;
    if(x.l > y.l)
        return 1;
    if(x.z < y.z)
        return -1;
    if(x.z > y.z)
        return 1;
    return 0;
}
void citire(data & d)
{
    cin >> d.a >> d.l >> d.z;
}
int main()
{
    int n, p, q; data dmin, dmax, d;
    cin >> n;
    citire(d);
    dmin = dmax = d;
    p = q = 1;
    for(int i = 2 ; i <= n ; i ++)
    {
        citire(d);
        if(data_cmp(d, dmin) < 0)
            dmin = d, q = i;
        if(data_cmp(d, dmax) > 0)
            dmax = d, p = i;
    }
    cout << p << " " << q;
    return 0;
}
