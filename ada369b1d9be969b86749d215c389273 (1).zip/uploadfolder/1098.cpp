#include<iostream>
#include<cstring>
#include<fstream>

using namespace std;

ifstream fin("reteta.in");
ofstream fout("reteta.out");

struct tip
{
    char produs[201];
    unsigned cant;
}v[204];

int cifra(char s)
{
    if(s<='9'&&s>='0')
        return 1;
    return 0;
}
int litera(char s)
{
    if(s>='a'&&s<='z')
        return 1;
    return 0;
}
int main()
{
    char s[2000],aux[2000];
    int timp=0,x=0;
    fin.get(s,2000);
    for(int i=1;i<strlen(s);i++)
    {
        if(cifra(s[i-1])&&s[i]=='(')
        {
            strcpy(aux,s+i);
            s[i]=' ';
            strcpy(s+i+1,aux);
        }
    }
    for(int i=1;i<strlen(s);i++)
    {
        if(s[i-1]==')')
        {
            while(s[i]==' ')
            {
                strcpy(aux,s+i+1);
                strcpy(s+i,aux);
                i--;
            }
            int j=i;
            x=0;
            while(cifra(s[j]))
            {
                x=x*10+s[j]-'0';
                j++;
            }
            timp=timp+x;
            strcpy(aux,s+j);
            strcpy(s+i,aux);
        }
    }
    for(int i=0;i<strlen(s)-1;i++)
    {
        if(s[i]=='('||s[i]==')')
        {
            strcpy(aux,s+i+1);
            strcpy(s+i,aux);
            i--;
        }
        if(s[i-1]==' '&&s[i]==' ')
        {
            while(s[i]==' ')
            {
                strcpy(aux,s+i+1);
                strcpy(s+i,aux);
            }
            i--;

        }
    }
    int k=0,j,c;
    for(int i=0;i<strlen(s);i++)
    {
        if(litera(s[i]))
        {
            c=0;
            k++;
            while(litera(s[i]))
            {
                v[k].produs[c]=s[i];
                c++;
                i++;
            }
        }
        int x=0;
        if(cifra(s[i]))
        {
            while(cifra(s[i]))
            {
                x=x*10+s[i]-'0';
                i++;
            }
            v[k].cant=x;
        }
    }
    for(int i=1;i<k;i++)
    {
        for(j=i+1;j<=k;j++)
        {
            if(strlen(v[i].produs)==strlen(v[j].produs)&&strcmp(v[i].produs,v[j].produs)==0)
            {
                v[i].cant=v[i].cant+v[j].cant;
                for(int r=j;r<k;r++)
                    v[r]=v[r+1];
                k--;
                j--;
            }
        }
    }
    for(int i=1;i<k;i++)
    {
        for(int j=i+1;j<=k;j++)
            if(strcmp(v[i].produs,v[j].produs)>0)
            {
                tip aux2;
                aux2=v[j];
                v[j]=v[i];
                v[i]=aux2;
            }
    }
    fout<<timp;
    fout<<endl;
    for(int i=1;i<=k;i++)
    {
        fout<<v[i].produs<<' '<<v[i].cant<<endl;
    }

    fin.close();
    fout.close();

    return 0;
}

