#include<iostream>
#include<cstring>
using namespace std;

int main()
{
    char s[101];
    cin>>s;
    int n=strlen(s),i,j=0;
    while(j<n)
    {
        for(i=0;i<n;i++)
            if(i!=j)
                cout<<s[i];
        cout<<endl;
        j++;
    }
}
