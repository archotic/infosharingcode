#include<iostream>
using namespace std;

int s(int n, int c1,int c2)
{
    int f;
    if(c1>c2)
        f=c1-c2;
    else
        f=c2-c1;
    if(n)
    {
        if(n % 10 == c1)
            return n % 10 + f + s(n / 10,c1,c2) * 10;
    }
    return 0;
}
int main()
{
    int n,c1,c2;
    cin >> n>>c1>>c2;
    cout << s(n,c1,c2);
}

