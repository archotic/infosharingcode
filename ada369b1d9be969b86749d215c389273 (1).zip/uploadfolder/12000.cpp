#include<iostream>
using namespace std;
int cifmax(int x)
{
    if(x<=9)
        return x;
    else
        return max(x%10,cifmax(x/10));
}
int main()
{
    int x;
    cin >> x;
    cout << cifmax(x);
}



