#include<iostream>
using namespace std;

int main()
{
    int x,y,m;
    cin>>x>>y;
    m=(x+y)%10;
    cout<<m;
    return 0;
}
