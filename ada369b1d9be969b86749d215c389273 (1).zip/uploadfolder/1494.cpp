#include<fstream>
#include<cstring>
using namespace std;

ifstream fin("s_p_c.in");
ofstream fout("s_p_c.out");

char s[101][45],p[101][45],c[101][45];

void sort_string(char s[101][45],int n)
{
    int i,j;
    char aux[45];
    for(i=0;i<n-1;i++)
        for(j=i+1;j<n;j++)
            if(strcmp(s[i],s[j])>0)
                strcpy(aux,s[i]),strcpy(s[i],s[j]),strcpy(s[j],aux);
}

int main()
{
    char a[45];
    int n,i,j,k,x,y,z;
    i=j=k=0;
    while(fin>>a)
    {
        n=strlen(a);
        if(a[n-1]=='S')
        {
            a[n-2]=0;
            strcpy(s[i++],a);
        }
        if(a[n-1]=='P')
        {
            a[n-2]=0;
            strcpy(p[j++],a);
        }
        if(a[n-1]=='C')
        {
            a[n-2]=0;
            strcpy(c[k++],a);
        }
    }
    sort_string(s,i);
    sort_string(p,j);
    sort_string(c,k);
    for(x=0;x<i;x++)
        for(y=0;y<j;y++)
            for(z=0;z<k;z++)
                fout<<s[x]<<" "<<p[y]<<" "<<c[z]<<endl;
}
