#include <iostream>
#include <cstring>
#include<fstream>
using namespace std;
int main()
{
    char z[1001],cuv[11],*p,*x,*y,aux[1001],cuv2[11];
    ifstream fin("inlocuirecuvant.in");
    ofstream fout("inlocuirecuvant.out");
    fin>>cuv>>cuv2;
    fin.get();
    fin.getline(z,101);
    p=strstr(z,cuv);
    while(p)
    {
        x=p+strlen(cuv);
        y=p+strlen(cuv2);
        if((z[x-z]==' '||z[x-z]=='\0')&&(p==z||z[p-z-1]==' '))
        {
            strcpy(aux,x);
            strcpy(y,aux);
            strncpy(p,cuv2,strlen(cuv2));
        }
        p=strstr(y+1,cuv);
    }
    fout<<z;
    return 0;
}
