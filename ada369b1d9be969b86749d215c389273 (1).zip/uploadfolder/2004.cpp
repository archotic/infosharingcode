#include <iostream>
#include <cstring>
#include <fstream>

using namespace std;
ifstream fin("ore.in");
ofstream fout("ore.out");

struct Timp
{
    int h, m, s;
}t1, t2;

int main()
{
    fin >> t1.h >> t1.m >> t1.s >> t2.h >> t2.m >> t2.s;
    fout << t1.h << ": " << t1.m << ": " << t1.s<<endl;
    fout << t2.h << ": " << t2.m << ": " << t2.s<<endl;
    int d1, d2, d, n;
    d1 = (t1.h)*3600 + (t1.m)*60 + t1.s;
    d2 = (t2.h)*3600 + (t2.m)*60 + t2.s;
    fout << d1 << endl << d2 << endl;
    d = d1+d2;
    n = d%3600;
    fout << d/3600 << ": " << n/60 << ": " << n%60;
    return 0;
}
