#include<iostream>
using namespace std;

int main()
{
    int C,P,G,A;
    cin>>C;
    P=2*C;
    G=2*P;
    A=C+P+G;
    cout<<A;
    return 0;
}
