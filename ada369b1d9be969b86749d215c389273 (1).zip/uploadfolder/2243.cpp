#include<iostream>
using namespace std;

int main()
{
    char c;
    int x=0,n=0;
    cin>>c;
    while(c!='.')
    {
        x=x+c;
        n++;
        cin>>c;
    }
    x=x/n;
    cout<<(char)x;
}
