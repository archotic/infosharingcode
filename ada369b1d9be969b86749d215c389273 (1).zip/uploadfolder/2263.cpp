#include<iostream>
using namespace std;

int main()
{
    int t1,t2,n,m,z,r;
    cin>>t1>>t2>>n>>m>>z;
    r=(t1*n+t2*m)*z;
    cout<<r;
    return 0;
}

