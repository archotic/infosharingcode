#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("coada2.in");

ofstream fout("coada2.out");

long long x,y,z,c;

int main()
{
  long long x,y,z,c;

  fin>>x>>y>>z;

  if (x>=y || x>=z) {

  fout<<-1; return 0;

 }

  c = y+z-x;

  fout<<((c<2) ? -1 : c);

  fin.close();

  fout.close();

}