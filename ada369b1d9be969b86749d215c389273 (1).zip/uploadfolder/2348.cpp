#include<iostream>
#include<cstring>
using namespace std;

int caracter_bun(char c)
{
    char vocale[]="aeiou";
    if(c==' ')
        return 0;
    if(c>='A' && c<='Z')
        return 0;
    if(strchr(vocale,c))
        return 0;
    return 1;
}

int main()
{
    char s[201];
    int ch_bune=0,cnt_bune=0,i,n;
    cin.get(s,201);
    n=strlen(s);
    for(i=0;i<n;i++)
    {
        if(caracter_bun(s[i]))
            ch_bune+=(int)s[i],cnt_bune++;
    }
    ch_bune=ch_bune/cnt_bune;
    cout<<(char)ch_bune;
}

