#include<fstream>
#include<cstring>
using namespace std;

ifstream fin("caesar.in");
ofstream fout("dbftbs.out");

int main()
{
    char s[256],op[10];
    int n,i;
    fin.get(s,256);
    fin>>n;
    fin.get();
    fin.get(op,10);
    if(op[0]=='d')
        n=26-n;
    n=n%26;
    for(i=0;i<strlen(s);i++)
    {
        if(s[i]>='A' && s[i]<='Z')
        {
            if(s[i]+n>'Z')
                s[i]='A'+n-('Z'-s[i])-1;
            else
                s[i]=s[i]+n;
        }
        if(s[i]>='a' && s[i]<='z')
        {
            if(s[i]+n>'z')
                s[i]='a'+n-('z'-s[i])-1;
            else
                s[i]=s[i]+n;
        }
    }
    fout<<s;
}
