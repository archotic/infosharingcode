#include<iostream>
#include<cstring>
using namespace std;

void Trim(char c[])
{
    int i=0;
    while(c[i]==' ')
    {
        for(int j=i;c[j];j++)
            c[j]=c[j+1];
    }
    int n=strlen(c);
    while(c[n-1]==' ')
    {
        c[n-1]=0,n--;
    }

}
int main()
{
    char c[101];
    cin.get(c,101);
    Trim(c);
    cout<<c;
}
