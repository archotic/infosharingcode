#include<iostream>
#include<cstring>
using namespace std;

int main()
{
    char s[256];
    cin.get(s,256);
    int sum=0,x=0,n=strlen(s),i;
    for(i=0;i<n;i++)
    {
        if(s[i]>='0' && s[i]<='9')
        {
            x=x*10+((int)s[i]-48);
        }
        else
        {
            if(x)
            {
                sum+=x;
                x=0;
            }
        }
    }
    cout<<sum;
}
