#include<iostream>
#include<cstring>
using namespace std;

int main()
{
    char s[256],distlmax[30],*p;
    int ok,n,i,j,gasit=0;
    cin.get(s,256);
    distlmax[0]=0;
    p=strtok(s," ");
    while(p)
    {
        ok=1;
        n=strlen(p);
        for(i=0;i<n-1;i++)
            for(j=i+1;j<n;j++)
                if(p[i]==p[j])
                    ok=0;
        if(ok && n>strlen(distlmax))
            strcpy(distlmax,p),gasit=1;
        p=strtok(NULL," ");
    }
    if(gasit)
        cout<<distlmax;
    else
        cout<<-1;
}
