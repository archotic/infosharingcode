#include<fstream>
#include<cstring>
using namespace std;

ifstream fin("perechivocale1.in");
ofstream fout("perechivocale1.out");

/*
Grupurile de vocale posibile:

aa ae ai ao au
ea ee ei eo eu
ia ie ii io iu
oa oe oi oo ou
ua ue ui uo uu
*/

int main()
{
    char grup_v[26][3]={"aa","ae","ai","ao","au","ea","ee"
    ,"ei","eo","eu","ia","ie","ii","io","iu","oa","oe","oi","oo","ou",
    "ua","ue","ui","uo","uu"};
    char s[41],g[3],aux[3];
    int v[26]={0},i,j,n,maxim=-1,ok=0;
    while(fin>>s)
    {
        n=strlen(s);
        for(i=0;i<n-1;i++)
        {
            aux[0]=s[i],aux[1]=s[i+1],aux[2]=0;
            for(j=0;j<26;j++)
                if(strcmp(grup_v[j],aux)==0)
                    v[j]++,ok=1;
        }
    }
    if(!ok)
        fout<<"NU";
    else
    {
        for(i=0;i<26;i++)
            if(v[i]>maxim)
                maxim=v[i];
        for(i=0;i<26;i++)
            if(v[i]==maxim)
                fout<<grup_v[i]<<" ";
    }

}
