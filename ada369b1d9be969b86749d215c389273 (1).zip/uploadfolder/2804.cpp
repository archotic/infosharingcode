#include<iostream>
#include<cstring>
using namespace std;

void string_reverse(char s[])
{
    int i,n=strlen(s);
    char aux;
    for(i=0;i<n/2;i++)
        aux=s[i],s[i]=s[n-i-1],s[n-i-1]=aux;
}

int main()
{
    char s[1000001],aux[1000001];
    int n,i,x;
    cin>>s;
    cin>>n;
    for(i=0;i<n;i++)
    {
        cin>>x;
        if(x%2==0)
            strncat(s,s,x);
        else
        {
            strncpy(aux,s,x);
            string_reverse(aux);
            strcat(s,aux);
        }
    }
    cout<<s;
}
