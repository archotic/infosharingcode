#include <iostream>
#include <fstream>
using namespace std;
int main()
{
ifstream f("zmeu.in");
ofstream g("zmeu.out");
long long N,M;
f >> N;
f >> M;
M=M*2;
g<<N/M<<"\n"<<M-(N%M);
return 0;
}
