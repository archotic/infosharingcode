#include <iostream>
#include <cstring>
#include<fstream>
using namespace std;
int main()
{
    char z[512],cuv[16],*p,*x,aux[256];
    ifstream fin("inserarechar.in");
    ofstream fout("inserarechar.out");
    fin.getline(cuv,16);
    fin.getline(z,256);
    int c=0;
    p=strstr(z,cuv);
    while(p)
    {
        x=p+strlen(cuv);
        if((z[x-z]==' '||z[x-z]=='\0')&&(p==z||z[p-z-1]==' '))
        {
            strcpy(aux,x);
            strcpy(x+1,aux);
            z[x-z]='?';
            c++;
        }
        p=strstr(x+1,cuv);
    }
    if(c==0)
        fout<<"NU APARE";
    else
        fout<<z;
    return 0;
}
