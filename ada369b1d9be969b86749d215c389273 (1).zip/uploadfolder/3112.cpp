#include<iostream>
#include<cstring>
using namespace std;

int main()
{
    char s[256],*p;
    int n,ok=0;
    cin.get(s,256);
    cin>>n;
    p=strtok(s," ");
    while(p)
    {
        if(strlen(p)==n)
        {
            cout<<p<<endl;
            ok=1;
        }
        p=strtok(NULL," ");
    }
    if(!ok)
        cout<<"nu exista";
}
