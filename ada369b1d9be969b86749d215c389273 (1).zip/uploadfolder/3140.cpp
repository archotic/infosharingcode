#include <iostream>
#include <cstring>
#include <fstream>

using namespace std;

ifstream fi("a1z26.in");
ofstream fo("a1z26.out");

int ebool(char s){
    char alf[]="abcdefghijklmnopqrstuvwxyz";
    int i = 0;
    for(i = 0 ; alf[i] ; i++){
        if(alf[i] == tolower(s))
            return i+1;
    }
}
void convert(int a , char &s){
    char alf[]="abcdefghijklmnopqrstuvwxyz";
    int i = 0;
    for(i = 0; alf[i] ; i++){
        if(i == a-1)
            s = alf[i];
    }
}
int main(){
    int p;
    fi >> p;
    fi.get();
    if(p==1){
        char s;
        while(fi >> s){
            fo << ebool(s) << " ";
        }
    } else {
        int n , j , a;
        char g;
        fi >> n ;
        for(j = 1; j <= n ; j++){
            fi >> a;
            convert(a,g);
            fo << char(toupper(g));
        }
    }
    return 0;
}