#include <iostream>
#include <cstring>
#include <fstream>

using namespace std;

ifstream fi("atbash.in");
ofstream fo("atbash.out");

void alfa(int a , char &s){

    char lfa[] = "zyxwvutsrqponmlkjihgfedcba";
    int i ;
    for(i = 0; lfa[i] ;i++){
        if(i == a-1)
            s = lfa[i];
    }
}
int main(){

    char s;
    char a;
    int g;
    while(fi >> s){
        if(toupper(s) == s){
            g = s-64;
            alfa(g,a);
            fo << char(toupper(a));
            g = 0;
        }
        else {
            g = s-96;
            alfa(g,a);
            fo << char(a);
            g = 0;
        }
    }
    return 0;
}