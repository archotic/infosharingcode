#include<iostream>
using namespace std;

int main()
{
    int f,b,n;
    long long x;
    cin>>f>>b>>n;
    x=f*3*n+b*2*n;
    cout<<x;
}