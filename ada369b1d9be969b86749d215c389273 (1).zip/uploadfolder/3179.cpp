#include<iostream>
#include<cmath>
using namespace std;

int main()
{
    int n;
    long long p;
    cin>>n;
    p=pow(n,5);
    cout<<p;
}
