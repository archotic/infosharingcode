#include<fstream>
#include<cstring>
using namespace std;

ifstream fin("ratc2.in");
ofstream fout("ratc2.out");

struct calator
{
    char nume[51],prenume[51];
    int bilet_platit;
    int penalizari;
};

calator v[100],aux;

int main()
{
    int n,i,j,bp,k=0,ok,m,c;
    char nm[51],prnm[51];
    fin>>m>>c;
    n=m;
    for(i=0;i<m;i++)
    {
        ok=0;
        fin>>prnm>>nm>>bp;
        for(j=0;j<k && !ok;j++)
        {
            if(strcmp(v[j].nume,nm)==0 && strcmp(v[j].prenume,prnm)==0)
            {
                if(!bp)
                    v[j].penalizari++;
                ok=1;
                n--;
            }
        }
        if(!ok)
        {
            strcpy(v[k].nume,nm);
            strcpy(v[k].prenume,prnm);
            if(!bp)
                v[k].penalizari++;
            k++;
        }
    }
    for(i=0;i<n-1;i++)
        for(j=i+1;j<n;j++)
        {
            if(v[i].penalizari<v[j].penalizari)
                aux=v[i],v[i]=v[j],v[j]=aux;
            else
            {
                if(v[i].penalizari==v[j].penalizari && strcmp(v[i].prenume,v[j].prenume)>0)
                    aux=v[i],v[i]=v[j],v[j]=aux;
                else
                    if(v[i].penalizari==v[j].penalizari && strcmp(v[i].prenume,v[j].prenume)==0 && strcmp(v[i].nume,v[j].nume)>0)
                        aux=v[i],v[i]=v[j],v[j]=aux;
            }
        }

    if(c==1)
        fout<<v[0].prenume<<" "<<v[0].nume<<" "<<v[0].penalizari<<endl;
    else
        for(i=0;i<n;i++)
            fout<<v[i].prenume<<" "<<v[i].nume<<" "<<v[i].penalizari<<endl;

}
