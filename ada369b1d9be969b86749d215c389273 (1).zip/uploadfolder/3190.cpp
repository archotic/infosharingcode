#include<fstream>
#include<cstring>
using namespace std;

ifstream fin("vigenere.in");
ofstream fout("vigenere.out");

int main()
{
    char a[256],b[256];
    fin>>a>>b;
    int i,n=strlen(a),m=strlen(b);
    for(i=0;i<n;i++)
    {
        if(a[i]+(b[i%m]-97)<=122)
            a[i]=a[i]+(b[i%m]-97);
        else
            a[i]=a[i]+(b[i%m]-123);
    }
    fout<<a;
}
