#include <iostream>
using namespace std;
int main()
{
int n,s=0,p=1,i;
cin>>n;
for(i=1;i<=n;i++)
{
p=2*i;
s=s+p;
}
cout<<"Suma este "<<s;
}
