#include <iostream>
using namespace std;
int main()
{
     long long p=1,n,i;
     cin>>n;
     for(i=1;i<=n;i++)
     {
     p=p*i;
     }
     cout<<p;
}