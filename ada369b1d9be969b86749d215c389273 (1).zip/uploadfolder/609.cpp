#include<iostream>
#include<cstring>
using namespace std;

int main()
{
    char s[256],aux[256];
    int i;
    cin.get(s,256);
    for(i=0;i<strlen(s);i++)
    {
        if(strchr("aeiou",s[i])!=0 && s[i]!=' ')
        {
            strcpy(aux,s+i+1);
            s[i+1]=s[i];
            strcpy(s+i+2,aux);
            i++;
        }
    }
    cout<<s;
}
