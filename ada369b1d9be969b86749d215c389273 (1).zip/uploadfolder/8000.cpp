#include<iostream>
using namespace std;
int sumcif(int x)
{
    if(x<=9)
        return x;
    else
        return x%10+sumcif(x/10);

}
int main()
{
    int x;
    cin >> x;
    cout << sumcif(x);
}


