#include<iostream>
#include<cstring>
using namespace std;

//  ana are  mere

int main()
{
    char s[256],aux[256];
    int n,i;
    cin.get(s,256);
    n=strlen(s);
    while(s[0]==' ')
    {
        strcpy(aux,s+1);
        strcpy(s,aux);
    }
    while(s[n-1]==' ')
    {
        s[n-1]=0;
        n--;
    }
    for(i=0;i<strlen(s)-1;i++)
    {
        if(s[i]==' ' && s[i+1]==' ')
        {
            strcpy(aux,s+i+1);
            strcpy(s+i,aux);
            i--;
        }
    }
    cout<<s;
}
