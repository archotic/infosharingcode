#include<iostream>
using namespace std;

int main()
{
    int a,b,c,t;
    cin>>a;
    b=2*a;
    c=b-3;
    t=a+b+c;
    cout<<t;
    return 0;
}
