#include<iostream>
#include<cstring>
using namespace std;

struct cuv_freq
{
    char cuv[16];
    int freq;
};

cuv_freq v[100],aux;

int main()
{
    char s[256],*p;
    cin.get(s,256);
    int n=0,i,j;
    p=strtok(s," ");
    while(p)
    {
        for(i=0;i<n && p;i++)
            if(strcmp(v[i].cuv,p)==0)
                v[i].freq++,p[0]=0;
        if(p)
        {
            strcpy(v[n].cuv,p);
            v[n].freq=1;
            n++;
        }
        p=strtok(NULL," ");
    }
    for(i=0;i<n-1;i++)
        for(j=i+1;j<n;j++)
            if(strcmp(v[i].cuv,v[j].cuv)>0)
            {
                aux=v[i];
                v[i]=v[j];
                v[j]=aux;
            }
    for(i=0;i<n;i++)
        if(strlen(v[i].cuv))
            cout<<v[i].cuv<<" "<<v[i].freq<<endl;
}
