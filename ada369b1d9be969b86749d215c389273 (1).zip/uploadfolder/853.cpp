#include<fstream>
#include<cstring>

using namespace std;

ifstream fin("cadouri.in");
ofstream fout("cadouri.out");

struct tip
{
    int cant;
    char nume[40];
}v[1001];

int litera(char s)
{
    if(s<='z'&&s>='a')
        return 1;
    return 0;
}

int cifra(char s)
{
    if(s<='9'&&s>='0')
        return 1;
    return 0;
}
int main()
{

    char s[500],aux[500];
    int n,m=0;
    fin>>n;
    for(int k=1;k<=n;k++)
    {
        fin.get();
        fin.get(s,500);
        int i,x,r=0;
        while(cifra(s[r])==0)
        {
            r++;
        }
        for(int i=r;i<strlen(s);i++)
        {
            x=0;
            if(cifra(s[i]))
            {
                m++;
                while(cifra(s[i]))
                {
                    x=x*10+s[i]-'0';
                    i++;
                }
                v[m].cant=x;
            }
            if(litera(s[i]))
            {
                int c=0;
                while(litera(s[i]))
                {
                    v[m].nume[c]=s[i];
                    c++;
                    i++;
                }
            }
        }
    }
    for(int i=1;i<m;i++)
    {
        for(int j=i+1;j<=m;j++)
        {
            if(strcmp(v[i].nume,v[j].nume)==0)
            {
                v[i].cant=v[i].cant+v[j].cant;
                for(int r=j;r<m;r++)
                {
                    v[r]=v[r+1];
                }
                i--;
                m--;
            }
        }
    }
    for(int i=1;i<m;i++)
    {
        for(int j=i+1;j<=m;j++)
        {
            if(v[i].cant<v[j].cant)
            {
                tip aux;
                aux=v[i];
                v[i]=v[j];
                v[j]=aux;
            }
            if(v[i].cant==v[j].cant)
            {
                if(strcmp(v[i].nume,v[j].nume)>0)
                {
                    tip aux;
                    aux=v[i];
                    v[i]=v[j];
                    v[j]=aux;
                }
            }

        }
    }
    fout<<m<<endl;
    for(int i=1;i<=m;i++)
    {
        fout<<v[i].nume<<' '<<v[i].cant<<endl;
    }

    fin.close();
    fout.close();



}
