#include<iostream>
using namespace std;
int primacif(int x)
{
    if(x<=9)
        return x;
    else
    {
        primacif(x/10);
        if(x<=9)
            return x;
    }
}
int main()
{
    int x;
    cin >> x;
    cout << primacif(x);
}


