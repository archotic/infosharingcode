#include <iostream>

 using namespace std;

 int main()
 {
     cout << "Sarbatori fericite";
     return 0;
 }