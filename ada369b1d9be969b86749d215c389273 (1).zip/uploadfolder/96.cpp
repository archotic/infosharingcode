#include <bits/stdc++.h>
using namespace std;
char s[256], c[25], *p, sep[]=" ,.:;";
int lu, maxx;

bool palindrom(char *p)
{
    int i, j;
char r[25];
strcpy(r, p);
for(i = 0; r[i]; i ++)
if(r[i] >= 'a')
r[i] = r[i] - 32;
for(i = 0, j = strlen(r) - 1; i < j; i ++, j --)
if(r[i] != r[j])
return false;
return true;
}

int main()
{
cin.getline(s, sizeof(s));
p = strtok(s, sep);
while(p)
{
    if(palindrom(p))
{
   lu = strlen(p);
       if(lu > maxx) maxx = lu, strcpy(c, p);
}
p = strtok(NULL, sep);
}
cout << c;
return 0;
}
