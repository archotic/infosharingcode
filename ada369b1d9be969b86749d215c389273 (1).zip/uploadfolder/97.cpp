#include<iostream>
#include<cstring>
using namespace std;

int main()
{
    char s1[21],s2[21],aux;
    int i,j,ok=1;
    cin>>s1>>s2;
    for(i=0;i<strlen(s1)-1;i++)
        for(j=i+1;j<strlen(s1);j++)
        {
            if(s1[i]>s1[j])
            {
                aux=s1[i];
                s1[i]=s1[j];
                s1[j]=aux;
            }
            if(s2[i]>s2[j])
            {
                aux=s2[i];
                s2[i]=s2[j];
                s2[j]=aux;
            }
        }
    for(i=0;i<strlen(s1) && ok==1;i++)
    {
        if(s1[i]!=s2[i])
            ok=0;
    }
    if(ok)
        cout<<1;
    else
        cout<<0;
    return 0;
}
