#include <iostream> 
#include <cstring> 
using namespace std; 
int main() { 
    char s[256]; 
    cin.getline(s, 256); 
    char * p = strtok(s , " "); 
    while(p) { 
        bool ok = true; 
        for(int i = 0 ; p[i] ; i ++) 
            if( ! strchr("aeiou" , p[i]) ) 
            	ok = false; 
            if(ok) 
            	cout << p << endl; 
            p = strtok( NULL , " "); 
    } 
    return 0; 
}

