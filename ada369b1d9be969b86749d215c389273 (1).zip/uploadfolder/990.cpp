#include<fstream>
#include<cstring>
using namespace std;

ifstream fin("sortarecuvinte1.in");
ofstream fout("sortarecuvinte1.out");

char s[200][31];

int main()
{
    char cuv[31],aux[31];
    int n=0,i,j;
    while(fin>>cuv)
        strcpy(s[n++],cuv);
    for(i=0;i<n-1;i++)
        for(j=i+1;j<n;j++)
            if(strcmp(s[i],s[j])>0)
            {
                strcpy(aux,s[i]);
                strcpy(s[i],s[j]);
                strcpy(s[j],aux);
            }
    for(i=0;i<n;i++)
        fout<<s[i]<<endl;
}
