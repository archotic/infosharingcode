#include <iostream>
#include <cstring>

using namespace std;

int main()
{
    char s[255], t[255];
    int i;

    cin.getline(s, sizeof(s));
    cin.getline(t, sizeof(t));

    for (i = 0; i < strlen(s); i++)
        if (strchr(t, s[i]))
            cout << s[i];
    return 0;
}
