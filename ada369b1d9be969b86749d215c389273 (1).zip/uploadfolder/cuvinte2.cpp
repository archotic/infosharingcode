#include <iostream>
#include <cstring>

using namespace std;

int main(){
	char s[256], sep[]=",. ",ult[256]="zzz";
	char *cuv;
	cin.getline(s,256);
	int gasit=0, i,ok=0,n;
	cuv= strtok(s,sep);
	while(cuv)
    {
        ok=1;
        n= strlen(cuv);
        for(i=0; i < n/2; i++)
            if(cuv[i] != cuv[n-i-1])
                ok = 0;
        if(ok)
        {
            gasit = 1;
            if(strcmp(cuv,ult) < 0)
                strcpy(ult,cuv);
        }
       cuv= strtok(NULL,sep);
    }
    if(gasit)
        cout<<ult;
    else
        cout<< "IMPOSIBIL";
    return 0;
}
