#include <fstream>
#include <cstring>
using namespace std;
int n, i, j, nr;
char s[35], voc[] = "aeiou";
bool ok;
int main()
{
    ifstream f("doarvocale.in");
    ofstream g("doarvocale.out");
    f >> n;
    for (i = 1; i<= n; i ++)
     {
         f >> s;
         ok = true;
         for (j = 0; s[j] != NULL; j ++)
          if(!strchr(voc, s[j]))
             {
                 ok = false;
                 break;
             }
         if (ok) nr ++;
     }
     g << nr;

    return 0;
}
