#include <iostream>
#include <cstring>

using namespace std;

int n;
char s[200];

int main()
{

    cin.getline(s,200);

    for(int i=0;i<strlen(s);i++)
        if(strchr("aeiou",s[i]))
        {
            for(int j=strlen(s)-1;j>=i;j--)
                s[j+1]=s[j];
            s[i]=s[i+1];
            i++;
        }

    cout << s;

    return 0;

}


