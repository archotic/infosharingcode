#include <iostream>
#include <cstring>

using namespace std;

int main(){
    char s[256], aux[256];
    cin.getline(s,256);
    int n = strlen(s);
    int i;
    for(i = 0 ; i < strlen(s) ; i++){
        if(strchr(" 0123456789",s[i]))
        {
            strcpy(aux, s+i+1);
            strcpy(s+i,aux);
            i--;
        }
   
    }
    cout << s;
    return 0;
}
