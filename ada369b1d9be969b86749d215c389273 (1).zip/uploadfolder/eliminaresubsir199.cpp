#include <iostream>
#include <cstring>
using namespace std;

int main()
{

    char s[256], voc[]="aeiou", t[256], aux[256];
    cin.getline(s, 256);
     cin.getline(t, 256);
    int i,j;
    while(strstr(s, t))
    {
        int poz = strstr(s,t) - s;
        strcpy(aux, s+poz +strlen(t));
        strcpy(s+poz, aux);
    }
    cout << s;
    return 0;
}

