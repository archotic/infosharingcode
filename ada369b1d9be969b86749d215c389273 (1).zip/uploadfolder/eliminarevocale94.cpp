#include <iostream>
#include <cstring>
using namespace std;

int main()
{
    char a[21], s[21];
    cin >> a;
    for (int i=0; i < strlen(a); i++)
        if (strchr("aeiouAEIOU", a[i]))
        {
            strcpy(s, a+i+1);
            strcpy(a+i, s);
            i--;
        }
    cout << a;
    return 0;
}
