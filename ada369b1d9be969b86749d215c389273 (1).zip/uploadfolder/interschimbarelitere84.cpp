#include <iostream>

using namespace std;

bool evocala(char b){

    char a = tolower(b);
    if(a == 'a' || a == 'e' || a == 'i' || a == 'o' || a == 'u')
        return true;
    else
        return false;
}
int main(){

    char a[256] , f , l;
    cin.getline(a,256);
    int i , j, pozf = 0 , pozl = 0;
    bool k = false, g = false;
    for(j = 0 ; a[j] ; j++){
        if(evocala(a[j]) == true)
        {
            f = a[j];
            pozf = j;
            k = true;
            break;
        }

    }
    for(j = 0 ; a[j] ; j++){
        if(evocala(a[j]) == false)
        {
            l = a[j];
            pozl = j;
            g = true;
        }
    }

    for(j = 0 ; a[j] ; j++){
        a[pozf] = l;
        a[pozl] = f;
    }
    if(k == true && g == true)
        cout << a;
    else
        cout << "IMPOSIBIL";
    return 0;
}