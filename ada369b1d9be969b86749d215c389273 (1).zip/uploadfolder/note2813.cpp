#include <iostream>
#include <cstring>
using namespace std;

char no[7][4]={"DO","RE","MI","FA","SOL","LA","SI"};
int nt = 7;

int main(){
	char cuv[101];
	bool exista = false;
	bool ok;
	while(cin >> cuv){
		ok = false;
		for(int i = 0; i < nt && !ok ; ++i)
            if(strstr(cuv , no[i]) != 0){
                exista = true;
                ok = true;
            }
        if(ok)
            cout << cuv << endl;
	}
	if(!exista)
        cout << "nu exista";
    return 0;
}
        