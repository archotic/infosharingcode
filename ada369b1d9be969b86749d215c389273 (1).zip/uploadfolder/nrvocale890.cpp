#include <iostream>
#include <string.h>
using namespace std;
int main(){
    char str[255];
    int i;
    int va=0,ve=0,vi=0,vo=0,vu=0,max;
    cin.get(str,255);
    for(i=0;i<strlen(str);i++){
        if(toupper(str[i]) == 'A') va++;
        else if(toupper(str[i]) == 'E') ve++;
        else if(toupper(str[i]) == 'I') vi++;
        else if(toupper(str[i]) == 'O') vo++;
        else if(toupper(str[i]) == 'U') vu++;
    }
    max=va;
    if(ve>max)max=ve;
    if(vi>max)max=vi;
    if(vo>max)max=vo;
    if(vu>max)max=vu;
    
    if(va==max)cout<<"A";
    else if(ve==max)cout<<"E";
    else if(vi==max)cout<<"I";
    else if(vo==max)cout<<"O";
    else cout<<"U";
    return 0;
}
