#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;

int n, i, nr;
char s[200], t[200], *p;
int main()
{
    gets(s);
    p = strtok(s, " ");
    strcpy(t, p);
    n = strlen(t);
    if(strchr("aeiouAEIOU", t[0]) && strchr("aeiouAEIOU", t[n - 1]))
        nr ++;
    while(p != NULL)
    {
        p = strtok(NULL, " ");
        if(p == NULL) break;
        memset(t, 0, sizeof(t));
        strcpy(t, p);
        n = strlen(t);
        if(strchr("aeiouAEIOU", t[0]) && strchr("aeiouAEIOU", t[n - 1]))
            nr ++;
    }
    printf("%d", nr);

    return 0;
}
