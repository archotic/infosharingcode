#include <fstream>
#include <cstring>
using namespace std;
int n,i,j,l,nr,maxx;
char s[255],t[255];
int main()
{
ifstream f("vocmax.in");
ofstream g("vocmax.out");
f>>n;
f.getline(s,255);
for(j=1;j<=n;j++)
{
    f.getline(s,255);
    nr=0;
    l=strlen(s);
    for(i=0; i<l; ++i)
 if(strchr("aeiou",s[i])) nr++;
        if(nr>maxx) maxx=nr,strcpy(t,s);
}
g<<t;
f.close();
g.close();
return 0;
}
