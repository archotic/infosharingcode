#include <iostream>
#include <cstring>
using namespace std;
char s[50], t[50], voc[]="aeiouAEIOU";
int lt, i;
int main()
{
    cin>>s;
    cin>>t;
    lt = strlen(t);
    for (i = 0; t[i] != NULL; i++)
     if (!strchr(voc, t[i])) cout << t[i];
    cout <<" ";
    cout << s;
    return 0;
}
