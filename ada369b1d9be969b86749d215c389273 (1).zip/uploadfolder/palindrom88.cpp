#include <iostream>
#include <fstream>
#include <cstring>
using namespace std;
ifstream fin("palindrom.in");
ofstream fout("palindrom.out");
int main()
{
    int n,i,m,j,h;
    bool ok;
    char v[100];
    fin>>n;
    fin.get();
    for(i=0;i<n;i++) {
        fin.getline(v,100);
        m = strlen(v);
        ok=1;
        j=0; h=m-1;
        while(j<m && h>=0) {
            if(v[j]!=v[h]) ok=0;
            j++; h--;
        }
        if(ok==1) fout<<"1";
        else fout<<"0";
        fout<<endl;
    }
    return 0;
}
