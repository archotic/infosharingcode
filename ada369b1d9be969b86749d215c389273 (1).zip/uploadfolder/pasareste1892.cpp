#include <iostream>
#include<stdio.h>
#include <cstring>
using namespace std;int main()
{
 char s[256], t[256];
 int i,j;

 cin.getline(s, 256);
 for (i = 0,j=0; i <= strlen(s); i++,j++)
 {
  if ((s[i] == 'a') || (s[i] == 'e') || (s[i] == 'i') || (s[i] == 'o') || (s[i] == 'u'))
  i += 2;
  t[j] = s[i];
 }

 cout << t; return 0;
}
