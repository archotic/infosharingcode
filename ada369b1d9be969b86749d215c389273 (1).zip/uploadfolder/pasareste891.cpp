#include <bits/stdc++.h>
using namespace std;
char s[256], t[512];
int n, i, j;
int main()
{
    cin.getline(s,sizeof(s));
    n = strlen(s);
    for(i = 0; i < n; i ++)
    {
        if(strchr("aeiou",s[i]))
          {
             t[j ++] = s[i];
             t[j ++] = 'p';
             t[j ++] = s[i];
          } else
             t[j ++] = s[i];
    }
   for(i = 0; i < j; i ++)
    cout << t[i];
   return 0;
}
