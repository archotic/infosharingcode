#include <iostream>
#include <cstring>
using namespace std;

char voc[10] = "aeiou";

bool vocala(char c)                 
{
    if(strchr(voc, c)) return true;

    return false;
}

int main()
{
    string s;
    int len, cnt = 0;
    bool last;
    getline(cin, s);
    len = s.length();
    last = vocala(s[0]);              
    for(int i = 1; i < len; ++i)
        {
            bool tmp = vocala(s[i]);
            if(tmp && last) cnt++;   
            last = tmp;              
        }
    cout<<cnt;
}
