#include <iostream>
#include <cstring>
using namespace std;

string v = "aeiou";

bool vocala(char c)
{   
for(int i = 0; i < 5; ++i)       
   if(c == v[i]) return true;   
return false;
}

bool consoana(char c)
{   
if(c < 'a' || c > 'z') return false;   
for(int i = 0; i < 5; ++i)       
   if(c == v[i]) return false;   
return true;
}

int main()
{   
string s;   
int cnt = 0;   
getline(cin, s);   
for(int i = 1; i < s.length() - 1; ++i)       
{           
    if(vocala(s[i]) && consoana(s[i - 1]) && consoana(s[i + 1])) cnt++;       
}   
cout<<cnt;
return 0;
}

