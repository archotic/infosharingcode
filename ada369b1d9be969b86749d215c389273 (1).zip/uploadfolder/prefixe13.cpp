#include <iostream>
#include <cstring>
using namespace std;
char s[11];
int i,j,k;
int main()
{
    cin.get(s,11);
    cout<<s;
    for(k=strlen(s)-1;k>=0;k--)
    {
        cout<<endl; 
        for(i=0;i<=k-1;i++)
            cout<<s[i];
    }
    cout<<s;
    for(j=0;j<=strlen(s)-1;j++)
    {
        cout<<endl;
        for(i=j+1;i<strlen(s);i++)
                cout<<s[i];   
    }
}

