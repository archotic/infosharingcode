#include <bits/stdc++.h>
using namespace std; 
char s[256], voc[] = "aeiou";
 int st, dr, i, j, maxx;
 int main() {
 cin.getline(s , sizeof(s)); 
for(i = 0; s[i]; i ++) {
 if(!strchr(voc, s[i]))
 {
 j ++;
 if(j >= maxx)
 maxx = j, st = i - j + 1, dr = i; }
 else j = 0; 
}
 s[dr + 1] = 0; 
cout << s + st; 
return 0;
 }
