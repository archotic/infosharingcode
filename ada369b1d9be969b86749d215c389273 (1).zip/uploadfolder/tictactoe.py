
import sys
table1 = ["1", "2" , "3" , "4" , "5" , "6" , "7" , "8" , "9"]

def table():
  print("Bine ati venit")
  for i in range(9):
    print(table1[i],end=" ")
    if(i == 2 or i == 5 or i == 8):
      print("")
def main():
  i = 0
  while(True): 
    table()
    if(i % 2 == 0):
      print("Player1 your turn : ")
      player1 = input()
      table1[converttointeger(player1)-1] = "X"
      i+=1
    elif(i % 2 != 0):
      print("Player2 your turn : ")
      player2 = input()
      table1[converttointeger(player2)-1] = "O"
      i+=1
    if(checkwin() == 1):
      if(i % 2 == 0):
        print("Felicitari player 2 ai castigat!!!")
        print("Do you want to play again ? [Y/N] y-i want to play n - i want to leave")
        choose = input()
        if(choose == "Y"):
          continue 
        else:
          sys.exit(exit())
      elif(i % 2 != 0):
        print("Felicitari player 1 ai castigat!!!")
        print("Do you want to play again ? [Y/N] y - i want to play n - i want to leave")
        choose = input()
        if(choose == "Y" or choose == "y"):
          continue 
        else:
          sys.exit(exit())

def checkwin():
  if(table1[0] == table1[1] and table1[2] == table1[1]):
    check = 1
  elif(table1[3] == table1[4] and table1[4] == table1[5]):
    check = 1
  elif(table1[6] == table1[7] and table1[7] == table1[8]):
    check = 1
  elif(table1[0] == table1[3] and table1[3] == table1[6]):
    check = 1
  elif(table1[1] == table1[4] and table1[4] == table1[7]):
    check = 1
  elif(table1[2] == table1[5] and table1[5] == table1[8]):
    check = 1
  elif(table1[0] == table1[4] and table1[4] == table1[8]):
    check = 1
  elif(table1[2] == table1[4] and table1[4] == table1[6]):
    check = 1
  else:
    check = 0
  return check
def converttointeger(integer):
  convert = int(integer)
  return convert
main()
