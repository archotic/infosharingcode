#include <bits/stdc++.h>
using namespace std;
int n, i;
char s[25], ch, voc[] = "aeiou";
int main()
{
    cin >> s;
    n = strlen(s);
    for(i = 0; i < n; i ++)
     if(strchr(voc, s[i])) s[i] = s[i] - ' ', cout << s[i];
      else cout << s[i];
    return 0;
}
